package base;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeTest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

public class TestBase {
	public static WebDriver driver;
	public static FileInputStream fis;
	public static Properties pro;
	public static ExtentReports report;
	public static ExtentTest test;
	public static Date d;
	public static SimpleDateFormat df;
	public static WebDriverWait wait;

	@BeforeTest
	public void setUp() {
		d = new Date();
		df = new SimpleDateFormat("dd_MM_YY");
		String date = df.format(d);

		if (driver == null) {
			ExtentSparkReporter spark = new ExtentSparkReporter("D:\\TieChennai\\AutomationFM\\src\\test\\resources\\report\\AutomationReport_" + date + ".html");

			//ExtentSparkReporter spark = new ExtentSparkReporter(System.getProperty("user.dir")+"/src/test/resources/report/AutomationReport_" + date + ".html");
			report = new ExtentReports();
			report.attachReporter(spark);
			test = report.createTest("Automation Report");

			pro = new Properties();
			try {
				fis = new FileInputStream(System.getProperty("user.dir") + "/src/test/resources/config/config.properties");
				pro.load(fis);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}

			if (pro.getProperty("browser").equalsIgnoreCase("chrome")) {
				test.log(Status.INFO, "Launching chrome browser");
				driver = new ChromeDriver();
			} else if (pro.getProperty("browser").equalsIgnoreCase("firefox")) {
				test.log(Status.INFO, "Launching firefox browser");
				driver = new FirefoxDriver();
			}

			test.log(Status.INFO, "Launching the URL " + pro.getProperty("testeingURL"));
			driver.get(pro.getProperty("URL"));
			driver.manage().window().maximize();
			test.log(Status.INFO, "Browser initiated");
		}
	}

	@AfterMethod
	public void getScreenshot(ITestResult r) throws IOException {
		String date = df.format(d);
		String screenshotPath = System.getProperty("user.dir") + "/src/test/resources/screenshot/screenshot_" + r.getName() + "_" + date + ".png";

		File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		File destFile = new File(screenshotPath);
		FileUtils.copyFile(srcFile, destFile);

		if (r.getStatus() == ITestResult.FAILURE) {
			test.log(Status.FAIL, "Test case " + r.getName() + " failed" + test.addScreenCaptureFromPath(screenshotPath));
		} else if (r.getStatus() == ITestResult.SUCCESS) {
			test.log(Status.PASS, "Test case " + r.getName() + " passed" + test.addScreenCaptureFromPath(screenshotPath));
		}
	}

	@AfterClass
	public void generateReport() {
		report.flush();
	}

	@AfterSuite
	public void tearDown() {
		if (driver != null) {
			//driver.quit();
		}
	}
}

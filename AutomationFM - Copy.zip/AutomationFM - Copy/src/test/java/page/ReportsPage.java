package page;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementClickInterceptedException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class ReportsPage {

    WebDriver driver;
    public ReportsPage( WebDriver driver ) {
        this.driver = driver;
        PageFactory.initElements( driver, this);
    }



    @FindBy(xpath="//button[@aria-label='Export to Excel']")
    private WebElement ReportsToExecelfileBtn;





    @FindBy(xpath="//p[text()='Reports']")
    private WebElement ReportsBtn;


    public void clickExportToExcel() throws InterruptedException {

        Thread.sleep(5000);

        ChromeOptions options = new ChromeOptions();
        Map<String, Object> prefs = new HashMap<>();
        prefs.put("download.default_directory", "D:\\TieChennai\\AutomationFM\\src\\test\\resources\\downloads");
        prefs.put("download.prompt_for_download", false);
        prefs.put("download.directory_upgrade", true);
        prefs.put("safebrowsing.enabled", true);
        options.setExperimentalOption("prefs", prefs);
        //driver = new ChromeDriver(options);

       // driver.get("http://example.com/download");

        // Find and click the download link
      //  WebElement reportsToExecelfileBtn = ReportsToExecelfileBtn;
        //reportsToExecelfileBtn.click();
        driver.findElement(By.xpath("//button[@aria-label='Export to Excel']")).click();

    }





    public void clickOnReports() throws InterruptedException {

        driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);
        WebElement element = ReportsBtn;
        int retries = 0;
        while (retries < 1000) {
            try {
                element.click();
                break; // Exit loop if click is successful
            } catch (ElementClickInterceptedException e) {
                retries++;
                Thread.sleep(2000); // Wait before retrying
            }
        }
        Thread.sleep(5000);


    }

    public void selectProject() throws InterruptedException
    {


        driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);
        WebElement element = driver.findElement(By.xpath("(//div[@id='demo-simple-select'])[2]"));
        int retries = 0;
        while (retries < 10000) {
            try {
                element.click();
                break; // Exit loop if click is successful
            } catch (ElementClickInterceptedException e) {
                retries++;
                Thread.sleep(5000); // Wait before retrying
            }
        }

        WebElement element1 = driver.findElement(By.xpath("//li[text()='Testing']"));
        element1.click();

       //Select select = new Select(element);

        // Select an option by visible text
      //  select.selectByVisibleText("Sage");




    }

    public void selectClient() throws InterruptedException
    {

        driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);
        WebElement element = driver.findElement(By.xpath("(//div[@id='demo-simple-select'])[1]"));
        int retries = 0;
        while (retries < 10000) {
            try {
                element.click();
                break; // Exit loop if click is successful
            } catch (ElementClickInterceptedException e) {
                retries++;
                Thread.sleep(5000); // Wait before retrying
            }
        }

        WebElement element1 = driver.findElement(By.xpath("//li[text()='Pearson US']"));
        element1.click();



        //Select select = new Select(element);

        // Select an option by visible text
       // select.selectByVisibleText("HAP");



    }






}

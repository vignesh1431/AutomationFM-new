package page;


import org.openqa.selenium.*;

import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class ImageExtractionPage {
WebDriver driver;

	
	public ImageExtractionPage(WebDriver d)
	{
		this.driver=d;
		
	}
	public void clickImageExtraction() throws InterruptedException {

		driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);
		//Thread.sleep(5000);
		driver.findElement(By.xpath("//p[text()='Image Extraction']")).click();
	}
	
	public void clickBrowseButton() throws InterruptedException
	{
		driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//p[text()='Browse']")).click();
		Thread.sleep(2000);	
	}
	public void uploadFile(String name) throws AWTException
	{
String fname=System.getProperty("user.dir")+"\\src\\test\\resources\\data\\"+name;
		
		StringSelection stringSelection = new StringSelection(fname);
		   Toolkit.getDefaultToolkit().getSystemClipboard().setContents(stringSelection, null);
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_CONTROL);
	    robot.keyPress(KeyEvent.VK_V);
	    robot.keyRelease(KeyEvent.VK_V);
	    robot.keyRelease(KeyEvent.VK_CONTROL);
	    robot.keyPress(KeyEvent.VK_ENTER);
	    robot.keyRelease(KeyEvent.VK_ENTER);
	}
	public void clickGetImages()
	{
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.findElement(By.xpath("//button[text()='Get Images']")).click();

		driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);
		// wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//img[@alt='Loading logo']")));		
	}
	public void getImageCount()
	{

        driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);
		int xpathCount= driver.findElements(By.xpath("//img[starts-with(@alt,'Image')]")).size();
		System.out.println("Image count is:"+xpathCount);
		//driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);
		// wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//img[@alt='Loading logo']")));
	}
	public int clickImageClasification() throws InterruptedException {
		int xpathCount=0;
		//driver.manage().timeouts().implicitlyWait(90, TimeUnit.MINUTES);
		int retries = 0;
		while (retries < 1000000000) {
			try {
				WebElement element =  driver.findElement(By.xpath("//button[text()='Classify Images']"));
				//driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);
				xpathCount= driver.findElements(By.xpath("//img[starts-with(@alt,'Image')]")).size();
				System.out.println("Image count is:"+xpathCount);

				element.click();
				break; // Exit loop if click is successful
			} catch (NoSuchElementException e) {
				retries++;
				Thread.sleep(5000); // Wait before retrying
			}
		}
		return xpathCount;

		// driver.findElement(By.xpath("//button[text()='Classify Images']")).click();
		//driver.manage().timeouts().implicitlyWait(90, TimeUnit.MINUTES);

	}
	
	public void selectProject() throws InterruptedException
	{
		Thread.sleep(2000);

		driver.findElement(By.xpath("//div[normalize-space(text())='Select project']")).click();

		List<WebElement>	project =driver.findElements(By.xpath("//ul[@role='listbox']//li"));
		for(WebElement c:project)
		{
		String name=	c.getAttribute("data-value");
		Thread.sleep(200);
		if(name.contains("Sage"))
		{
			c.click();
			break;
		}
		}
		Thread.sleep(200);
	}
	
	public void selectClient() throws InterruptedException
	{
		WebElement element = driver.findElement(By.xpath("//div[normalize-space(text())='Select client']"));
		int retries = 0;
		while (retries < 100000) {
			try {
				element.click();
				break; // Exit loop if click is successful
			} catch (ElementClickInterceptedException e) {
				retries++;
				Thread.sleep(5000); // Wait before retrying
			}
		}

		List<WebElement>	client =driver.findElements(By.xpath("//ul[@role='listbox']//li"));
		Thread.sleep(2000);
		for(WebElement c:client)
		{
		String name=	c.getAttribute("data-value");
		System.out.println(name);
		Thread.sleep(20000);
		if(name.contains("HAP"))
		{
			c.click();
			break;
		}
		}
	}
	
	public void clickSaveAndNext()
	{
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//button[text()='Save & Next']")).click();
	}

}

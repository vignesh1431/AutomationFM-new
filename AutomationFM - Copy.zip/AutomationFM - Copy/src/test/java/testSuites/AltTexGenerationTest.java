package testSuites;

import base.TestBase;
import org.testng.annotations.Test;
import page.AltTextGenerationPage;
import page.LoginPage;
import page.ReportsPage;

import java.awt.*;

public class AltTexGenerationTest extends TestBase {

    @Test(priority=1)
    public void login()
    {
        LoginPage lp = new LoginPage(driver);
        lp.clicksubmit();
//		 lp.enterUserName("ialtadmin@integra.co.in");
//		 lp.enterPassword("Admin@123");
        lp.enterUserName(pro.getProperty("UserNameValue"));
        lp.enterPassword(pro.getProperty("passwordValue"));
        lp.loginButton();
    }
    @Test(priority=2)
    public void AltTexGeneration() throws AWTException, InterruptedException {
        AltTextGenerationPage al = new AltTextGenerationPage(driver);
        al.clickOnAltTextGeneration();
        al.selectClient();
        al.selectProject();
        al.selectAssert();
        al.uploadFile("sample-img.jpg");


       // al.clickOnAltTextGeneration();
        al.clickNext();
        al.clickGenerateAltText();
        ReportsPage rp= new ReportsPage(driver);
        rp.clickOnReports();




    }
}

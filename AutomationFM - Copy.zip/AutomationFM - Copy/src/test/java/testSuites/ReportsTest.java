package testSuites;

import base.TestBase;
import org.testng.annotations.Test;
import page.ImageClassificationPage;
import page.LoginPage;
import page.ReportsPage;

import java.awt.*;

public class ReportsTest  extends TestBase {

    @Test(priority=1)
    public void login()
    {
        LoginPage lp = new LoginPage(driver);
        lp.clicksubmit();
        // lp.enterUserName("ialtadmin@integra.co.in");
        // lp.enterPassword("Admin@123");
        lp.enterUserName(pro.getProperty("UserNameValue"));
        lp.enterPassword(pro.getProperty("passwordValue"));
        lp.loginButton();
    }
    @Test(priority=2)
    public void ReportsClick() throws AWTException, InterruptedException {
        ReportsPage rp = new ReportsPage(driver);
        rp.clickOnReports();
        rp.selectClient();
        rp.selectProject();
        rp.clickExportToExcel();





    }





}
